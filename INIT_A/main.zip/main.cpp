#include <iostream>

using namespace std;

int main() {
    cout << "Ahoj pazdejir" << endl;
    return 0;
}
